
import React from "react";

function Checkout() {
  return (
    <div style={padding:'40px'}>
      <h2>Checkout Page</h2>
      <p>This is a demo screen aligned with PPT flow.</p>
    </div>
  );
}

export default Checkout;
