
import React from "react";

function Signup() {
  return (
    <div style={padding:'40px'}>
      <h2>Signup Page</h2>
      <p>This is a demo screen aligned with PPT flow.</p>
    </div>
  );
}

export default Signup;
