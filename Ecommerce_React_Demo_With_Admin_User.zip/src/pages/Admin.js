
import React from "react";

function Admin() {
  return (
    <div style={padding:'40px'}>
      <h2>Admin Dashboard</h2>
      <p>This is a demo screen aligned with PPT flow.</p>
    </div>
  );
}

export default Admin;
