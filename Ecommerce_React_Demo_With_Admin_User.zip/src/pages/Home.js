
import React from "react";

function Home() {
  return (
    <div style={padding:'40px'}>
      <h2>User Storefront</h2>
      <p>This is a demo screen aligned with PPT flow.</p>
    </div>
  );
}

export default Home;
