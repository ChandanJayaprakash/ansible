
import React from "react";

function Login() {
  return (
    <div style={padding:'40px'}>
      <h2>Login Page (User/Admin)</h2>
      <p>This is a demo screen aligned with PPT flow.</p>
    </div>
  );
}

export default Login;
